const express = require('express')
const mongoose = require('mongoose')
const cors = require('cors')
const { DB_URL } = require('./config.json')
const usersRouter = require('./routers/usersRouter')
const goalsRouter = require('./routers/goalsRouter')

const app = express();
mongoose.connect(DB_URL,{
            useNewUrlParser: true,
            useUnifiedTopology: true
})
.then(() => {
            console.log('DB connected')
            app.listen(3000, () => console.log('Listening on 3000...'))
})
.catch((e) => {
            console.error(e)
})

//middleware
app.use(cors())
app.use(express.json())

//routes
app.use('/users', usersRouter)
app.use('/goals', goalsRouter)

app.use(function(err, req, res, next) {
     res.status(500).json({success: false, data: err.message})
})